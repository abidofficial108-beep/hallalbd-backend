const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'db.json');

app.use(cors());
app.use(bodyParser.json());

// Helper to read DB
const readDb = () => {
    try {
        if (!fs.existsSync(DB_PATH)) return {};
        const data = fs.readFileSync(DB_PATH, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error("Error reading DB:", error);
        return {};
    }
};

// Helper to write DB
const writeDb = (data) => {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error("Error writing DB:", error);
        return false;
    }
};

// --- PUBLIC APIs ---

// GET /products - Get all products
app.get('/products', (req, res) => {
    const db = readDb();
    res.json(db.products || []);
});

// GET /settings - Get site settings
app.get('/settings', (req, res) => {
    const db = readDb();
    res.json(db.settings || {});
});

// GET /categories - Get categories
app.get('/categories', (req, res) => {
    const db = readDb();
    res.json(db.categories || []);
});

// GET /pages/:slug - Get static page content
app.get('/pages/:slug', (req, res) => {
    const db = readDb();
    const page = db.pages ? db.pages[req.params.slug] : null;
    if (page) {
        res.json(page);
    } else {
        res.status(404).json({ error: "Page not found" });
    }
});

// POST /orders - Create a new order
app.post('/orders', (req, res) => {
    const { customer, items, total, shipping } = req.body;
    
    if (!customer || !items || !total) {
        return res.status(400).json({ error: "Missing required fields" });
    }

    const db = readDb();
    const orderId = 'ORD-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
    
    const newOrder = {
        id: orderId,
        date: new Date().toISOString(),
        status: 'pending', // pending, processing, shipped, delivered, cancelled
        customer,
        items,
        total,
        shipping,
        history: [
            { status: 'pending', date: new Date().toISOString(), note: 'Order placed' }
        ]
    };

    if (!db.orders) db.orders = [];
    db.orders.push(newOrder);
    
    writeDb(db);
    res.status(201).json(newOrder);
});

// GET /orders/:orderId - Get order details
app.get('/orders/:orderId', (req, res) => {
    const db = readDb();
    const order = db.orders ? db.orders.find(o => o.id === req.params.orderId) : null;
    if (order) {
        res.json(order);
    } else {
        res.status(404).json({ error: "Order not found" });
    }
});

// --- ADMIN APIs ---

// GET /admin/data - Get full DB
app.get('/admin/data', (req, res) => {
    const db = readDb();
    res.json(db);
});

// POST /admin/update - Update full DB (simplest way for admin panel to manage everything)
app.post('/admin/update', (req, res) => {
    const newData = req.body;
    if (!newData) return res.status(400).json({ error: "No data provided" });
    
    // Safety check: preserve orders if not provided (though admin should handle this)
    // But for this simple implementation, we assume admin sends full valid state or we handle partial updates.
    // The prompt says "Admin is the ONLY way to manage products, offers, pages".
    // We'll allow updating specific keys.
    
    const db = readDb();
    const updatedDb = { ...db, ...newData };
    
    // Ensure we don't accidentally wipe orders if they are missing in the payload (unless intended)
    // For safety, let's say this endpoint is for settings/products/pages.
    if (!newData.orders) {
        updatedDb.orders = db.orders;
    }

    writeDb(updatedDb);
    res.json({ success: true });
});

// PATCH /orders/:orderId/status - Update order status
app.patch('/orders/:orderId/status', (req, res) => {
    const { status, note } = req.body;
    const db = readDb();
    const orderIndex = db.orders ? db.orders.findIndex(o => o.id === req.params.orderId) : -1;

    if (orderIndex === -1) {
        return res.status(404).json({ error: "Order not found" });
    }

    db.orders[orderIndex].status = status;
    db.orders[orderIndex].history.push({
        status,
        date: new Date().toISOString(),
        note: note || `Status changed to ${status}`
    });

    writeDb(db);
    res.json(db.orders[orderIndex]);
});

// PATCH /orders/:orderId/cancel - Cancel order
app.patch('/orders/:orderId/cancel', (req, res) => {
    const db = readDb();
    const orderIndex = db.orders ? db.orders.findIndex(o => o.id === req.params.orderId) : -1;

    if (orderIndex === -1) {
        return res.status(404).json({ error: "Order not found" });
    }

    // Check if already shipped
    if (['shipped', 'delivered'].includes(db.orders[orderIndex].status)) {
        return res.status(400).json({ error: "Cannot cancel shipped order" });
    }

    db.orders[orderIndex].status = 'cancelled';
    db.orders[orderIndex].history.push({
        status: 'cancelled',
        date: new Date().toISOString(),
        note: 'Order cancelled by user/admin'
    });

    writeDb(db);
    res.json(db.orders[orderIndex]);
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
